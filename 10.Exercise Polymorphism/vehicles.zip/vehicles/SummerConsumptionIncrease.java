package vehicles;

class SummerConsumptionIncrease {
    static final double CAR_FUEL_INCREASE = 0.9;
    static final double TRUCK_FUEL_INCREASE = 1.6;
}
