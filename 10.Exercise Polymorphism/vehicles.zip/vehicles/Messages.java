package vehicles;

class Messages {
    static final String VEHICLE_NEEDS_FUEL = "needs refueling";
}
