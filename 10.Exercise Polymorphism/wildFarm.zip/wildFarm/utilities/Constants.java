package wildFarm.utilities;

public class Constants {
    public static final String DEFAULT_CAT_SOUND = "Meowwww";
    public static final String DEFAULT_TIGER_SOUND = "ROAAR!!!";
    public static final String DEFAULT_MOUSE_SOUND = "SQUEEEAAAK!";
    public static final String DEFAULT_ZEBRA_SOUND = "Zs";
    public static final String INPUT_TERMINATING_COMMAND = "END";

}
