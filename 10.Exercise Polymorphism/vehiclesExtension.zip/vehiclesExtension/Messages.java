package vehiclesExtension;

class Messages {
    static final String VEHICLE_NEEDS_FUEL = "needs refueling";
    static final String FUEL_NEGATIVE_VALUE_WARNING = "Fuel must be a positive number";
    static final String TANK_OVERLOADED_WARNING = "Cannot fit fuel in tank";
}
