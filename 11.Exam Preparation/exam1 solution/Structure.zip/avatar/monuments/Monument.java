package avatar.monuments;

abstract class Monument {
    private String name;

    Monument(String name) {
        this.name = name;
    }
}
